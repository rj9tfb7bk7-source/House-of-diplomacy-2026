(function(){var b=document.querySelector('.menu-btn'),n=document.getElementById('nav');
if(b)b.addEventListener('click',function(){var o=n.classList.toggle('open');b.setAttribute('aria-expanded',o)});
var f=document.getElementById('cform');
if(f)f.addEventListener('submit',function(e){e.preventDefault();if(f.website.value)return;
var m=f.message.value.trim(),em=f.email.value.trim();
if(!f.name.value.trim()||!/^\S+@\S+\.\S+$/.test(em)||m.length<10){document.getElementById('cerr').textContent='Please enter your name, a valid email and a message (10+ characters).';return}
location.href='mailto:hello@houseofdiplomacy.com?subject='+encodeURIComponent(f.topic.value+' - '+f.name.value)+'&body='+encodeURIComponent(m+'\n\nFrom: '+f.name.value+' <'+em+'>')});
var q=document.getElementById('q');
if(q){var D=[],o=document.getElementById('results');fetch('/search-index.json').then(function(r){return r.json()}).then(function(d){D=d;run()});
function run(){var t=q.value.toLowerCase().trim();o.innerHTML='';D.filter(function(x){return!t||(x.t+' '+x.d).toLowerCase().indexOf(t)>-1}).forEach(function(x){var a=document.createElement('p');a.innerHTML='<a href="'+x.u+'"><strong>'+x.t+'</strong></a><br>'+x.d;o.appendChild(a)});if(!o.children.length)o.textContent='No matches. Try another word.'}
q.addEventListener('input',run)}})();
